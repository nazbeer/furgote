// App.js
import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Tooltip, LayersControl } from 'react-leaflet';
import axios from 'axios';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './App.css';

const { BaseLayer } = LayersControl;

const defaultMarkerIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const App = () => {
  const [points, setPoints] = useState([]);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [weatherData, setWeatherData] = useState(null);
  const [isEarthView, setIsEarthView] = useState(false);

  useEffect(() => {
    axios.get('http://localhost:5000/api/points')
      .then(response => setPoints(response.data))
      .catch(error => console.error('Failed to fetch points:', error));
  }, []);

  useEffect(() => {
    const fetchWeatherData = async (lat, lon) => {
      try {
        const response = await axios.get(`http://localhost:5000/api/weather/${lat}/${lon}`);
        setWeatherData(response.data);
      } catch (error) {
        console.error('Failed to fetch weather data:', error);
      }
    };

    if (selectedPoint) {
      fetchWeatherData(selectedPoint.northing, selectedPoint.easting);
    }
  }, [selectedPoint]);

  const handleMarkerClick = (point) => {
    setSelectedPoint(point);
  };

  const toggleView = () => {
    setIsEarthView(!isEarthView);
  };

  return (
    <div className="app">
      <MapContainer center={[50, 0]} zoom={5} style={{ height: '80vh', width: '100%' }}>
        <LayersControl position="topright">
          <BaseLayer checked name="Map View">
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          </BaseLayer>
          <BaseLayer name="Earth View">
            <TileLayer
              url="https://www.google.com/maps/vt?lyrs=s&x={x}&y={y}&z={z}"
              attribution='&copy; Google'
              maxZoom={20}
            />
          </BaseLayer>
        </LayersControl>

        {points && points.map(point => (
          <Marker
            key={point.id}
            position={[point.northing, point.easting]}
            icon={defaultMarkerIcon}
            onClick={() => handleMarkerClick(point)}
          >
            <Popup>
              <div>
                <strong>ID:</strong> {point.id}<br />
                <strong>Depth:</strong> {point.depth}<br />
                <strong>Layer Amount:</strong> {point.layerAmount}
              </div>
            </Popup>
            <Tooltip>{point.id}</Tooltip>
          </Marker>
        ))}
      </MapContainer>

      {selectedPoint && weatherData && (
  <div className="modal">
    <div className="modal-content">
      <span className="close" onClick={() => setSelectedPoint(null)}>&times;</span>
      <table>
        <tbody>
          <tr>
            <td><strong>ID:</strong></td>
            <td>{selectedPoint.id}</td>
          </tr>
          <tr>
            <td><strong>Depth:</strong></td>
            <td>{selectedPoint.depth}</td>
          </tr>
          <tr>
            <td><strong>Layer Amount:</strong></td>
            <td>{selectedPoint.layerAmount}</td>
          </tr>
          <tr>
            <td><strong>Weather:</strong></td>
            <td>{weatherData.weather[0].description}</td>
          </tr>
          <tr>
            <td><strong>Temperature:</strong></td>
            <td>{weatherData.main.temp}°C</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
)}

      <div className="grid-container2">
        {points.map(point => (
          <div key={point.id} className={`marker-info`} >
            <div className="grid-container">
              <div><strong>ID:</strong></div>
              <div>{point.id}</div>

              <div><strong>Depth:</strong></div>
              <div>{point.depth}</div>

              <div><strong>Layer Amount:</strong></div>
              <div>{point.layerAmount}</div>

              <div><strong>Easting:</strong></div>
              <div>{point.easting}</div>

              <div><strong>Northing:</strong></div>
              <div>{point.northing}</div>
              <button className="button" onClick={() => handleMarkerClick(point)}>View on Map</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
