import React from 'react';

const PointDetailsModal = ({ point, onClose }) => {
  if (!point) return null;

  return (
    <div className="point-details-modal">
      <h2>Point Details</h2>
      <p><strong>ID:</strong> {point.id}</p>
      <p><strong>Depth:</strong> {point.depth} m</p>
      <p><strong>Layer Amount:</strong> {point.layerAmount}</p>
      <button onClick={onClose}>Close</button>
    </div>
  );
};

export default PointDetailsModal;
