const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
//require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
mongoose.connect('mongodb+srv://nazbeer:Qwerty123@cluster0.hggovns.mongodb.net/points', { useNewUrlParser: true, useUnifiedTopology: true });

// Enable CORS
app.use(cors());

// API routes
const pointsRouter = require('./routes/points');
app.use('/api/points', pointsRouter);

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
