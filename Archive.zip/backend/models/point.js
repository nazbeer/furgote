// models/point.js
const mongoose = require('mongoose');

const pointSchema = new mongoose.Schema({
  id: String,
  easting: Number,
  northing: Number,
  depth: Number,
  layerAmount: Number,
  weather: {
    description: String,
    temperature: Number,
  },
});

const Point = mongoose.model('Point', pointSchema);

module.exports = Point;
