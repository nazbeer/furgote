const express = require('express');
const axios = require('axios');
const Point = require('../models/point');

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const points = await Point.find();
        res.json(points);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch points' });
    }
});

router.get('/weather/:lat/:lng', async (req, res) => {
    const { lat, lng } = req.params;
    try {
        const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=be5ab6ae194ebd60a1a13a6230b214cf`);
   
        const weatherData = {
            description: response.data.weather[0].description,
            temperature: response.data.main.temp,
          };
      
          res.json(weatherData);
          console.log(weatherData);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch weather data' });
    }
});

module.exports = router;
